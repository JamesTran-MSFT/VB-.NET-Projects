' Name:         Bonnette Project
' Purpose:      Display the number of gallons 
'               needed to fill a rectangular pool
' Programmer:   <your name> on <current date>

Public Class frmMain

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' displays the number of gallons

        Dim pool As New RectangularPool
        Dim dblGallons As Double

        Double.TryParse(txtLength.Text, pool.Length)
        Double.TryParse(txtWidth.Text, pool.Width)
        Double.TryParse(txtDepth.Text, pool.Depth)

        dblGallons = pool.GetGallons
        lblGallons.Text = dblGallons.ToString("N0")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtLength_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtLength.KeyPress
        ' allow only numbers, the period, and the Backspace key

        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso
            e.KeyChar <> "." AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtWidth_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtWidth.KeyPress
        ' allow only numbers, the period, and the Backspace key

        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso
            e.KeyChar <> "." AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtDepth_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDepth.KeyPress
        ' allow only numbers, the period, and the Backspace key

        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso
            e.KeyChar <> "." AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtLength_TextChanged(sender As Object, e As EventArgs) Handles txtLength.TextChanged
        lblGallons.Text = String.Empty
    End Sub

    Private Sub txtWidth_TextChanged(sender As Object, e As EventArgs) Handles txtWidth.TextChanged
        lblGallons.Text = String.Empty
    End Sub

    Private Sub txtDepth_TextChanged(sender As Object, e As EventArgs) Handles txtDepth.TextChanged
        lblGallons.Text = String.Empty
    End Sub
End Class
