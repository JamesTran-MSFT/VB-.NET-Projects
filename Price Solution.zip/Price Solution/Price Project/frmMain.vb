﻿' Name:         Price Project
' Purpose:      Display the new price
' Programmer:   <your name> on <current date>

Public Class frmMain

    Private Function GetNewPrice(ByVal dblOld As Double) As Double
        ' Increases current price by 5% and returns a new price

        Dim dblNew As Double
        dblNew = dblOld * 1.05
        Return dblNew
    End Function

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' calls a function to calculate the new price
        ' and then displays the new price

        Dim dblPrice As Double

        Double.TryParse(txtCurrentPrice.Text, dblPrice)

        ' get the new price
        dblPrice = GetNewPrice(dblPrice)
        lblNewPrice.Text = dblPrice.ToString("C2")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtCurrentPrice_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCurrentPrice.KeyPress
        ' allows the text box to accept only numbers, the period, and the Backspace key

        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> "." AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtCurrentPrice_TextChanged(sender As Object, e As EventArgs) Handles txtCurrentPrice.TextChanged
        lblNewPrice.Text = String.Empty
    End Sub
End Class
