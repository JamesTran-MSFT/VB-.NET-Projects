﻿' Name:         Net Income Project
' Purpose:      Display the annual net income
' Programmer:   James Tran 14 April 2017

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' Calculates and displays the annual net income

        lblNetIncome.Text = Val(txtRevenue.Text) - Val(txtExpenses.Text)

    End Sub
End Class
