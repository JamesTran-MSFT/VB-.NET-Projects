﻿' Name:         SwatTheBugs Project
' Purpose:      Display the average score
' Programmer:   <your name> on <current date>

Public Class frmMain

    Private Sub btnExit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnCalc_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCalc.Click
        ' calculates and displays the average of three test scores

        lblAverage.Text = Val(txtTest1.Text) + Val(txtTest2.Text) + Val(txtTest3.Text) / 3

    End Sub
End Class
