﻿' Name:         Circle Area Project
' Purpose:      Display the area of a circle
' Programmer:   <your name> on <current date>

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim circle As New Circle
        Dim dblRadius As Double

        Double.TryParse(txtRadius.Text, circle.Radius)

        dblRadius = circle.GetArea
        lblArea.Text = dblRadius.ToString("#,##0.00")
    End Sub
End Class
