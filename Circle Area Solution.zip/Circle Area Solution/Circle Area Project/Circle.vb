﻿Public Class Circle
    Private _dblRadius As Double

    Public Property Radius As Double
        Get
            Return _dblRadius
        End Get
        Set(value As Double)
            If value > 0 Then
                _dblRadius = value
            Else
                _dblRadius = 0
            End If
        End Set
    End Property

    Public Function CircleArea() As Double
        Return _dblRadius * _dblRadius
    End Function

    Public Function GetArea() As Double
        Dim dblRadius As Double
        dblRadius = CircleArea
        Return dblRadius * 3.141592
    End Function
End Class
