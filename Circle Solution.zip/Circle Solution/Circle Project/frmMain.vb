﻿' Name:         Circle Project
' Purpose:      Display the circumference of a circle
' Programmer:   <your name> on <current date>

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' Calculates and displays the circumference of a circle

        ' Declare named constant
        Const dblPI As Double = 3.14

        ' Declare variables
        Dim dblDiameter As Double
        Dim dblCircumference As Double

        ' Store diameter in a variable
        Double.TryParse(txtDiameter.Text, dblDiameter)

        'Calculate circumference
        dblCircumference = dblPI * dblDiameter

        ' Display cicrumference
        lblCircumference.Text = dblCircumference.ToString("N2")

    End Sub
End Class
