﻿Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Close Application
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' Calculate lbs of Coffee and Decafe
        lblTotal.Text = Val(txtCoffee.Text) + Val(txtDecaf.Text)

        ' Declare Starbeans Price
        Const dPrice As Decimal = 11.65

        ' Declare variables
        Dim Price As Decimal

        ' Store price in a variable
        Decimal.TryParse(lblPrice.Text, Price)

        ' Calculate total price
        lblPrice.Text = "$" & Val(lblTotal.Text) * dPrice.ToString("C2")



    End Sub
End Class
