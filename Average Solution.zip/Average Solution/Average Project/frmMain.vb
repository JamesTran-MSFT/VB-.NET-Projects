﻿Public Class frmMain
    'James Tran
    'Visual Basic 
    'April 16, 2017 Unit 2 Project
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Calculate, by adding all text box numbers
        lblAverage.Text = Val(txtNum1.Text) + Val(txtNum2.Text) + Val(txtNum3.Text)
        'Find Average of added numbers and dividing by 3
        lblAverage.Text = Val(lblAverage.Text) / 3

    End Sub
End Class
