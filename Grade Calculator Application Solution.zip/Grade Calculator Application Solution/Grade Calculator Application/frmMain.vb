﻿Public Class frmMain
    Private Sub btnGrade_Click(ByVal sender As System.Object, e As System.EventArgs) Handles btnGrade.Click
        GradeList.Items.Add(txtGrade.Text)
        txtGrade.Clear()
    End Sub

    Private Sub btnAverage_Click(ByVal sender As System.Object, e As System.EventArgs) Handles btnAverage.Click
        ' Loop until user enters an empty string
        Dim Results As String
        Do
            Results = InputBox("How many assignments have you had?", "Assignment Grade?")
        Loop Until Results <> String.Empty

        ' Grades 
        Dim Total As Double
        Dim Avg As Double
        Dim Grade As Double
        Dim Gradecount As Integer
        For Gradecount = 0 To GradeList.Items.Count - 1
            Grade = GradeList.Items(Gradecount)
            Total = Grade
        Next
        ' Grade Totals
        Avg = Total / GradeList.Items.Count
        If (Total >= 90) Then lblResults.Text = "Your Grade is an A"
        If (Total <= 89) Then lblResults.Text = "Your Grade is a B"
        If (Total <= 79) Then lblResults.Text = "Your Grade is a C"
        If (Total <= 69) Then lblResults.Text = "Your Grade is a D"
        If (Total <= 59) Then lblResults.Text = "Your Grade is an F"

    End Sub

    Private Sub btnClearGrade_Click1(sender As Object, e As EventArgs) Handles btnClearGrade.Click
        lblResults.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
