﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblGrades = New System.Windows.Forms.Label()
        Me.GradeList = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtGrade = New System.Windows.Forms.TextBox()
        Me.btnGrade = New System.Windows.Forms.Button()
        Me.btnAverage = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblResults = New System.Windows.Forms.Label()
        Me.btnClearGrade = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblGrades
        '
        Me.lblGrades.AutoSize = True
        Me.lblGrades.Location = New System.Drawing.Point(12, 9)
        Me.lblGrades.Name = "lblGrades"
        Me.lblGrades.Size = New System.Drawing.Size(44, 13)
        Me.lblGrades.TabIndex = 0
        Me.lblGrades.Text = "Grades:"
        '
        'GradeList
        '
        Me.GradeList.FormattingEnabled = True
        Me.GradeList.Location = New System.Drawing.Point(15, 25)
        Me.GradeList.Name = "GradeList"
        Me.GradeList.Size = New System.Drawing.Size(70, 160)
        Me.GradeList.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(141, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Enter Grade:"
        '
        'txtGrade
        '
        Me.txtGrade.Location = New System.Drawing.Point(124, 25)
        Me.txtGrade.Name = "txtGrade"
        Me.txtGrade.Size = New System.Drawing.Size(100, 20)
        Me.txtGrade.TabIndex = 3
        Me.txtGrade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnGrade
        '
        Me.btnGrade.Location = New System.Drawing.Point(98, 51)
        Me.btnGrade.Name = "btnGrade"
        Me.btnGrade.Size = New System.Drawing.Size(75, 23)
        Me.btnGrade.TabIndex = 4
        Me.btnGrade.Text = "Submit Grade"
        Me.btnGrade.UseVisualStyleBackColor = True
        '
        'btnAverage
        '
        Me.btnAverage.Location = New System.Drawing.Point(185, 51)
        Me.btnAverage.Name = "btnAverage"
        Me.btnAverage.Size = New System.Drawing.Size(75, 23)
        Me.btnAverage.TabIndex = 5
        Me.btnAverage.Text = "Calculate"
        Me.btnAverage.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(152, 89)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Results:"
        '
        'lblResults
        '
        Me.lblResults.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblResults.Location = New System.Drawing.Point(105, 102)
        Me.lblResults.Name = "lblResults"
        Me.lblResults.Size = New System.Drawing.Size(139, 50)
        Me.lblResults.TabIndex = 7
        Me.lblResults.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnClearGrade
        '
        Me.btnClearGrade.Location = New System.Drawing.Point(98, 155)
        Me.btnClearGrade.Name = "btnClearGrade"
        Me.btnClearGrade.Size = New System.Drawing.Size(75, 23)
        Me.btnClearGrade.TabIndex = 8
        Me.btnClearGrade.Text = "Clear Grade"
        Me.btnClearGrade.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(185, 155)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(272, 195)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClearGrade)
        Me.Controls.Add(Me.lblResults)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnAverage)
        Me.Controls.Add(Me.btnGrade)
        Me.Controls.Add(Me.txtGrade)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GradeList)
        Me.Controls.Add(Me.lblGrades)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Grade Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblGrades As System.Windows.Forms.Label
    Friend WithEvents GradeList As System.Windows.Forms.ListBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtGrade As System.Windows.Forms.TextBox
    Friend WithEvents btnGrade As System.Windows.Forms.Button
    Friend WithEvents btnAverage As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblResults As System.Windows.Forms.Label
    Friend WithEvents btnClearGrade As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button

End Class
