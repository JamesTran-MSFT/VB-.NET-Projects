﻿Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnAmIRight_Click(sender As Object, e As EventArgs) Handles btnAmIRight.Click
      
        'Alabama and Montgomery
        If radAlabama.Checked = radMontgomery.Checked Then
            lblAnswer.Text = "Correct"
        Else : lblAnswer.Text = "Try Again"
        End If

        'Alaska and Juneau
        If radAlaska.Checked = radJuneau.Checked Then
            lblAnswer.Text = "Correct"
        Else : lblAnswer.Text = "Try Again"
        End If

        ' Arizona and Phoenix
        If radArizona.Checked = radPhoenix.Checked Then
            lblAnswer.Text = "Correct"
        Else : lblAnswer.Text = "Try Again"
        End If

        'Arkanasa and LittleRock
        If radArkansas.Checked = radLittleRock.Checked Then
            lblAnswer.Text = "Correct"
        Else : lblAnswer.Text = "Try Again"
        End If

        ' California and Sacramento
        If radCalifornia.Checked = radSacramento.Checked Then
            lblAnswer.Text = "Correct"
        Else : lblAnswer.Text = "Try Again"
        End If

        ' Colorado and Denver
        If radColorado.Checked = radDenver.Checked Then
            lblAnswer.Text = "Correct"
        Else : lblAnswer.Text = "Try Again"
        End If

        ' Connecticut and Hartford
        If radConnecticut.Checked = radHartford.Checked Then
            lblAnswer.Text = "Correct"
        Else : lblAnswer.Text = "Try Again"
        End If

        ' Delaware and Dover
        If radDelaware.Checked = radDover.Checked Then
            lblAnswer.Text = "Correct"
        Else : lblAnswer.Text = "Try Again"
        End If

        ' Florida and Tallahassee
        If radFlorida.Checked = radTallahassee.Checked Then
            lblAnswer.Text = "Correct"
        Else : lblAnswer.Text = "Try Again"
        End If

        ' Georgia and Atlanta
        If radGeorgia.Checked = radAtlanta.Checked Then
            lblAnswer.Text = "Correct"
        Else : lblAnswer.Text = "Try Again"
        End If

    End Sub
End Class
