﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.lblAnswer = New System.Windows.Forms.Label()
        Me.btnAmIRight = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.radAlabama = New System.Windows.Forms.RadioButton()
        Me.radAlaska = New System.Windows.Forms.RadioButton()
        Me.radArizona = New System.Windows.Forms.RadioButton()
        Me.radArkansas = New System.Windows.Forms.RadioButton()
        Me.radCalifornia = New System.Windows.Forms.RadioButton()
        Me.radColorado = New System.Windows.Forms.RadioButton()
        Me.radConnecticut = New System.Windows.Forms.RadioButton()
        Me.radDelaware = New System.Windows.Forms.RadioButton()
        Me.radFlorida = New System.Windows.Forms.RadioButton()
        Me.radGeorgia = New System.Windows.Forms.RadioButton()
        Me.radPhoenix = New System.Windows.Forms.RadioButton()
        Me.radDenver = New System.Windows.Forms.RadioButton()
        Me.radDover = New System.Windows.Forms.RadioButton()
        Me.radAtlanta = New System.Windows.Forms.RadioButton()
        Me.radMontgomery = New System.Windows.Forms.RadioButton()
        Me.radSacramento = New System.Windows.Forms.RadioButton()
        Me.radTallahassee = New System.Windows.Forms.RadioButton()
        Me.radLittleRock = New System.Windows.Forms.RadioButton()
        Me.radHartford = New System.Windows.Forms.RadioButton()
        Me.radJuneau = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Location = New System.Drawing.Point(6, 274)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(40, 13)
        Me.lblResult.TabIndex = 0
        Me.lblResult.Text = "Result:"
        '
        'lblAnswer
        '
        Me.lblAnswer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAnswer.Location = New System.Drawing.Point(40, 291)
        Me.lblAnswer.Name = "lblAnswer"
        Me.lblAnswer.Size = New System.Drawing.Size(87, 23)
        Me.lblAnswer.TabIndex = 1
        '
        'btnAmIRight
        '
        Me.btnAmIRight.Location = New System.Drawing.Point(179, 291)
        Me.btnAmIRight.Name = "btnAmIRight"
        Me.btnAmIRight.Size = New System.Drawing.Size(87, 23)
        Me.btnAmIRight.TabIndex = 2
        Me.btnAmIRight.Text = "Am I Right?"
        Me.btnAmIRight.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(274, 291)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(87, 23)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'radAlabama
        '
        Me.radAlabama.AutoSize = True
        Me.radAlabama.Location = New System.Drawing.Point(6, 19)
        Me.radAlabama.Name = "radAlabama"
        Me.radAlabama.Size = New System.Drawing.Size(66, 17)
        Me.radAlabama.TabIndex = 4
        Me.radAlabama.Text = "Alabama"
        Me.radAlabama.UseVisualStyleBackColor = True
        '
        'radAlaska
        '
        Me.radAlaska.AutoSize = True
        Me.radAlaska.Location = New System.Drawing.Point(6, 42)
        Me.radAlaska.Name = "radAlaska"
        Me.radAlaska.Size = New System.Drawing.Size(57, 17)
        Me.radAlaska.TabIndex = 9
        Me.radAlaska.Text = "Alaska"
        Me.radAlaska.UseVisualStyleBackColor = True
        '
        'radArizona
        '
        Me.radArizona.AutoSize = True
        Me.radArizona.Location = New System.Drawing.Point(6, 65)
        Me.radArizona.Name = "radArizona"
        Me.radArizona.Size = New System.Drawing.Size(60, 17)
        Me.radArizona.TabIndex = 10
        Me.radArizona.Text = "Arizona"
        Me.radArizona.UseVisualStyleBackColor = True
        '
        'radArkansas
        '
        Me.radArkansas.AutoSize = True
        Me.radArkansas.Location = New System.Drawing.Point(6, 85)
        Me.radArkansas.Name = "radArkansas"
        Me.radArkansas.Size = New System.Drawing.Size(69, 17)
        Me.radArkansas.TabIndex = 11
        Me.radArkansas.Text = "Arkansas"
        Me.radArkansas.UseVisualStyleBackColor = True
        '
        'radCalifornia
        '
        Me.radCalifornia.AutoSize = True
        Me.radCalifornia.Location = New System.Drawing.Point(6, 108)
        Me.radCalifornia.Name = "radCalifornia"
        Me.radCalifornia.Size = New System.Drawing.Size(68, 17)
        Me.radCalifornia.TabIndex = 12
        Me.radCalifornia.Text = "California"
        Me.radCalifornia.UseVisualStyleBackColor = True
        '
        'radColorado
        '
        Me.radColorado.AutoSize = True
        Me.radColorado.Location = New System.Drawing.Point(6, 131)
        Me.radColorado.Name = "radColorado"
        Me.radColorado.Size = New System.Drawing.Size(67, 17)
        Me.radColorado.TabIndex = 13
        Me.radColorado.Text = "Colorado"
        Me.radColorado.UseVisualStyleBackColor = True
        '
        'radConnecticut
        '
        Me.radConnecticut.AutoSize = True
        Me.radConnecticut.Location = New System.Drawing.Point(6, 154)
        Me.radConnecticut.Name = "radConnecticut"
        Me.radConnecticut.Size = New System.Drawing.Size(82, 17)
        Me.radConnecticut.TabIndex = 14
        Me.radConnecticut.Text = "Connecticut"
        Me.radConnecticut.UseVisualStyleBackColor = True
        '
        'radDelaware
        '
        Me.radDelaware.AutoSize = True
        Me.radDelaware.Location = New System.Drawing.Point(6, 177)
        Me.radDelaware.Name = "radDelaware"
        Me.radDelaware.Size = New System.Drawing.Size(70, 17)
        Me.radDelaware.TabIndex = 15
        Me.radDelaware.Text = "Delaware"
        Me.radDelaware.UseVisualStyleBackColor = True
        '
        'radFlorida
        '
        Me.radFlorida.AutoSize = True
        Me.radFlorida.Location = New System.Drawing.Point(6, 200)
        Me.radFlorida.Name = "radFlorida"
        Me.radFlorida.Size = New System.Drawing.Size(56, 17)
        Me.radFlorida.TabIndex = 16
        Me.radFlorida.Text = "Florida"
        Me.radFlorida.UseVisualStyleBackColor = True
        '
        'radGeorgia
        '
        Me.radGeorgia.AutoSize = True
        Me.radGeorgia.Location = New System.Drawing.Point(6, 223)
        Me.radGeorgia.Name = "radGeorgia"
        Me.radGeorgia.Size = New System.Drawing.Size(62, 17)
        Me.radGeorgia.TabIndex = 17
        Me.radGeorgia.Text = "Georgia"
        Me.radGeorgia.UseVisualStyleBackColor = True
        '
        'radPhoenix
        '
        Me.radPhoenix.AutoSize = True
        Me.radPhoenix.Location = New System.Drawing.Point(6, 19)
        Me.radPhoenix.Name = "radPhoenix"
        Me.radPhoenix.Size = New System.Drawing.Size(63, 17)
        Me.radPhoenix.TabIndex = 18
        Me.radPhoenix.Text = "Phoenix"
        Me.radPhoenix.UseVisualStyleBackColor = True
        '
        'radDenver
        '
        Me.radDenver.AutoSize = True
        Me.radDenver.Location = New System.Drawing.Point(6, 42)
        Me.radDenver.Name = "radDenver"
        Me.radDenver.Size = New System.Drawing.Size(60, 17)
        Me.radDenver.TabIndex = 19
        Me.radDenver.Text = "Denver"
        Me.radDenver.UseVisualStyleBackColor = True
        '
        'radDover
        '
        Me.radDover.AutoSize = True
        Me.radDover.Location = New System.Drawing.Point(6, 65)
        Me.radDover.Name = "radDover"
        Me.radDover.Size = New System.Drawing.Size(54, 17)
        Me.radDover.TabIndex = 20
        Me.radDover.Text = "Dover"
        Me.radDover.UseVisualStyleBackColor = True
        '
        'radAtlanta
        '
        Me.radAtlanta.AutoSize = True
        Me.radAtlanta.Location = New System.Drawing.Point(6, 88)
        Me.radAtlanta.Name = "radAtlanta"
        Me.radAtlanta.Size = New System.Drawing.Size(58, 17)
        Me.radAtlanta.TabIndex = 21
        Me.radAtlanta.Text = "Atlanta"
        Me.radAtlanta.UseVisualStyleBackColor = True
        '
        'radMontgomery
        '
        Me.radMontgomery.AutoSize = True
        Me.radMontgomery.Location = New System.Drawing.Point(6, 108)
        Me.radMontgomery.Name = "radMontgomery"
        Me.radMontgomery.Size = New System.Drawing.Size(83, 17)
        Me.radMontgomery.TabIndex = 22
        Me.radMontgomery.Text = "Montgomery"
        Me.radMontgomery.UseVisualStyleBackColor = True
        '
        'radSacramento
        '
        Me.radSacramento.AutoSize = True
        Me.radSacramento.Location = New System.Drawing.Point(6, 131)
        Me.radSacramento.Name = "radSacramento"
        Me.radSacramento.Size = New System.Drawing.Size(82, 17)
        Me.radSacramento.TabIndex = 23
        Me.radSacramento.Text = "Sacramento"
        Me.radSacramento.UseVisualStyleBackColor = True
        '
        'radTallahassee
        '
        Me.radTallahassee.AutoSize = True
        Me.radTallahassee.Location = New System.Drawing.Point(6, 154)
        Me.radTallahassee.Name = "radTallahassee"
        Me.radTallahassee.Size = New System.Drawing.Size(82, 17)
        Me.radTallahassee.TabIndex = 24
        Me.radTallahassee.Text = "Tallahassee"
        Me.radTallahassee.UseVisualStyleBackColor = True
        '
        'radLittleRock
        '
        Me.radLittleRock.AutoSize = True
        Me.radLittleRock.Location = New System.Drawing.Point(6, 177)
        Me.radLittleRock.Name = "radLittleRock"
        Me.radLittleRock.Size = New System.Drawing.Size(76, 17)
        Me.radLittleRock.TabIndex = 25
        Me.radLittleRock.Text = "Little Rock"
        Me.radLittleRock.UseVisualStyleBackColor = True
        '
        'radHartford
        '
        Me.radHartford.AutoSize = True
        Me.radHartford.Location = New System.Drawing.Point(6, 200)
        Me.radHartford.Name = "radHartford"
        Me.radHartford.Size = New System.Drawing.Size(63, 17)
        Me.radHartford.TabIndex = 26
        Me.radHartford.Text = "Hartford"
        Me.radHartford.UseVisualStyleBackColor = True
        '
        'radJuneau
        '
        Me.radJuneau.AutoSize = True
        Me.radJuneau.Location = New System.Drawing.Point(6, 223)
        Me.radJuneau.Name = "radJuneau"
        Me.radJuneau.Size = New System.Drawing.Size(60, 17)
        Me.radJuneau.TabIndex = 27
        Me.radJuneau.Text = "Juneau"
        Me.radJuneau.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radAlabama)
        Me.GroupBox1.Controls.Add(Me.radAlaska)
        Me.GroupBox1.Controls.Add(Me.radArizona)
        Me.GroupBox1.Controls.Add(Me.radCalifornia)
        Me.GroupBox1.Controls.Add(Me.radArkansas)
        Me.GroupBox1.Controls.Add(Me.radColorado)
        Me.GroupBox1.Controls.Add(Me.radConnecticut)
        Me.GroupBox1.Controls.Add(Me.radDelaware)
        Me.GroupBox1.Controls.Add(Me.radFlorida)
        Me.GroupBox1.Controls.Add(Me.radGeorgia)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 18)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(157, 244)
        Me.GroupBox1.TabIndex = 28
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "State"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.radDenver)
        Me.GroupBox2.Controls.Add(Me.radPhoenix)
        Me.GroupBox2.Controls.Add(Me.radJuneau)
        Me.GroupBox2.Controls.Add(Me.radDover)
        Me.GroupBox2.Controls.Add(Me.radHartford)
        Me.GroupBox2.Controls.Add(Me.radAtlanta)
        Me.GroupBox2.Controls.Add(Me.radLittleRock)
        Me.GroupBox2.Controls.Add(Me.radSacramento)
        Me.GroupBox2.Controls.Add(Me.radTallahassee)
        Me.GroupBox2.Controls.Add(Me.radMontgomery)
        Me.GroupBox2.Location = New System.Drawing.Point(204, 18)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(157, 244)
        Me.GroupBox2.TabIndex = 29
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Capitals"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(375, 324)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAmIRight)
        Me.Controls.Add(Me.lblAnswer)
        Me.Controls.Add(Me.lblResult)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "State Capitals"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents lblAnswer As System.Windows.Forms.Label
    Friend WithEvents btnAmIRight As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents radAlabama As System.Windows.Forms.RadioButton
    Friend WithEvents radAlaska As System.Windows.Forms.RadioButton
    Friend WithEvents radArizona As System.Windows.Forms.RadioButton
    Friend WithEvents radArkansas As System.Windows.Forms.RadioButton
    Friend WithEvents radCalifornia As System.Windows.Forms.RadioButton
    Friend WithEvents radColorado As System.Windows.Forms.RadioButton
    Friend WithEvents radConnecticut As System.Windows.Forms.RadioButton
    Friend WithEvents radDelaware As System.Windows.Forms.RadioButton
    Friend WithEvents radFlorida As System.Windows.Forms.RadioButton
    Friend WithEvents radGeorgia As System.Windows.Forms.RadioButton
    Friend WithEvents radPhoenix As System.Windows.Forms.RadioButton
    Friend WithEvents radDenver As System.Windows.Forms.RadioButton
    Friend WithEvents radDover As System.Windows.Forms.RadioButton
    Friend WithEvents radAtlanta As System.Windows.Forms.RadioButton
    Friend WithEvents radMontgomery As System.Windows.Forms.RadioButton
    Friend WithEvents radSacramento As System.Windows.Forms.RadioButton
    Friend WithEvents radTallahassee As System.Windows.Forms.RadioButton
    Friend WithEvents radLittleRock As System.Windows.Forms.RadioButton
    Friend WithEvents radHartford As System.Windows.Forms.RadioButton
    Friend WithEvents radJuneau As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox

End Class
